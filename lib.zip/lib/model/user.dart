class User {
  static String id = " ";
  static String employeeId = " ";
  static String firstName = " ";
  static String lastName = " ";
  static String birthDate = " ";
  static String address = " ";
  static String profilePicLink = " ";
  static double lat = 0;
  static double long = 0;
  static bool canEdit = true;
}
